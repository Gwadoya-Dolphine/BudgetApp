<?php
$servername = "localhost";
$databasename="budgetapp";
$username = "root";
$password = "";

// Create connection
$conn = new mysqli($servername, $username, $password, $databasename);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
//echo "Connected successfully";
?>
<?php

if(isset($_GET['id'])) {
  $selectedid=$_GET['id'];
}

elseif (isset($_POST['btn_update'])) {
  $id= $_POST['id'];
  $itemname= $_POST['itemname'];
  $itemcost= $_POST['itemcost'];
  $query="UPDATE tbl_budgetitem SET itemname='{$itemname}', itemcost='{$itemcost}' 
  WHERE id=$id";
  $result=mysqli_query($conn, $query) or die(mysqli_error($conn));
  header("Location: edit.php");
}

else{
  header("Location: index.php");
}
  //fetch
  $query="SELECT * FROM tbl_budgetitem WHERE id=$selectedid";
  $result=mysqli_query($conn, $query) or die(mysqli_error($conn));
  while ($row=mysqli_fetch_array($result)) {
      $itemname=$row['itemname'];
      $itemcost=$row['itemcost'];
    }

?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<body  style="background-color: cyan;">
  <div class="container-fluid">
    <div class="row">
    <div class="col-md-2"></div>
      <div class="col-md-8" id="index">


  <!-- form2 start -->
  <form class="form-control" method="POST" action="edit.php">

    <input type="hidden" name="id" value="<?php echo $selectedid; ?>">
    Itemname:<br>
    <input type="text" name="itemname"  value="<?php echo $itemname; ?>" placeholder="Enter item name">
    <br>
    <input type="text" name="itemcost" value="<?php echo $itemcost; ?>" placeholder="Enter item cost">
    <br>
    <input type="submit" name="btn_update" value="Update">
    <br>
    <input type="submit" name="btn btn_danger" value="Cancel">
  </form>
  <!-- form2 collapse -->

  </div>

  <div class="col-md-2"></div>
  </div>
</body>
</html>