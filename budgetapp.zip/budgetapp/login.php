<?php 
        //require connection
        require("includes/connection.php");

        //require session
        require("includes/session.php");
?>
<?php

     //check whether form has been submitted
     if (isset($_POST['btn_login'])) {//
      //form data
       $email =  mysqli_escape_string($conn, $_POST['email']);
       $password = md5($_POST['password']);

      $query = "SELECT * FROM budgetapp_tbl WHERE email = '$email' AND password = '$password' ";
      $result = mysqli_query($conn, $query)  OR die(mysqli_error($conn));

       $row = mysqli_fetch_array($result);

       if ($row > 0 ){
          
              //user exist
               $_SESSION['email']  = $email;
               header("Location: index.php");
      }
      else{
        //no user exists
        header("Location: login.php?error_login=true");
      }



     }//

?>
<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script>
  function validateform() {
    var email= document.login_form.email.value;
    var password= document.login_form.password.value;
    

    if (email=="") {
      alert("Please enter email");
      return false;
    }
    else if(password==""){
      alert("Please enter password");
      return false;
    }
    
    }
  }
</script>
</head>
<body>
<div class="container-fluid" id="log" >
  <div class="row" >
    <div class="col-md-2"></div>
       <div class="col-md-8" id="bg">
            <h1 style="text-align: center;font-family: arial;font-size: 26px; color:#fff;margin-top: 50px;margin-bottom: 50px;" > LOGIN FORM</h1>

            
           <?php if(isset($_GET['success'])){// ?>
      <div class="alert alert-success">
        Registered successfully
      </div>
            <?php }// ?>

            <?php if(isset($_GET['error_login'])){// ?> 
      <div class="alert alert-danger">
        Access denied
      </div>
            <?php }// ?>
      
      <form action="login.php" method="post">
               <label style="color: white;">Enter Email</label>
                <input type="email" class="form-control" name="email" required="">
                <label style="color: white;">Enter Password</label>
                <input type="password" class="form-control" name="password" required="">
                <br/>
                <input type="submit" name="btn_login" value="Login" class="btn btn-success" style="width: 100%">
      </form>

      <h3 align="center" style="font-size: 16px;color: white;"><a href="register.php">CREATE ACCOUNT</a></h3>

    </div>
    </div>
        <div class="col-md-2"></div>
  </div>

</div>

</body>
</html>