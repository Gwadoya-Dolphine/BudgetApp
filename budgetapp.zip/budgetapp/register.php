<?php
  //require connection
  require("includes /connection.php");
?>
<?php

if (isset($_POST['btn_register'])) {


  $fname = ucfirst(mysqli_escape_string($conn, $_POST['fname']));
  $lname = ucfirst(mysqli_escape_string($conn, $_POST['lname']));
  $email = mysqli_escape_string($conn, $_POST['email']);
  $password = md5($_POST['password']);

  $query = "INSERT INTO budgetapp_tbl (firstname,lastname,email,password) 
  VALUES ('{$fname}','{$lname}','{$email}','{$password}')";

  $result = mysqli_query($conn,$query) OR die(mysqli_error($conn));
  header("Location:login.php?success=true");
 

}


?>

 <!DOCTYPE html>
<html lang="en">
<head>
  <title>Register Form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link rel="stylesheet" type="text/css" href="css/style.css">

  <!-- start script -->
<script>
	function validateform() {
		var fname= document.register_form.fname.value;
		var lname= document.register_form.lname.value;
		var email= document.register_form.email.value;
		var password= document.register_form.password.value;
		var confirm= document.register_form.confirm.value;

		if (fname=="") {
			alert("Please enter first name");
			return false;
		}
		else if(lname==""){
			alert("Please enter last name");
			return false;
		}
		else if(email==""){
			alert("Please enter email");
			return false;
		}
		else if(password==""){
			alert("Please enter password ");
			return false;
		}
		else if(confirm==""){
			alert("Please enter confirm password");
			return false;
		}
	}
</script>
<!-- script collapse -->
</head>
<body >
 <div class="container-fluid" id="ff">
 	<div class="col-md-2"></div>
 	<div class="col-md-8" >
 		<h1 style="text-align: center;font-family: arial;font-size: 26px; color:#fff;margin-top: 50px;margin-bottom: 50px;" > REGISTRATION FORM</h1>

 	          <?php
 	            if (isset($_GET['success'])) {
 	              	# code...
 	             
 	          ?>
 	          <div class="alert alert-success alert-dismissable">
                      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                      <strong>Registered Successfully!</strong> 
                    </div>
 	          <?php } ?>

 	          <?php
 	            if (isset($_GET['error_login'])) {
 	              	# code...
 	              	?>
 	           <div class="alert alert-danger">
                   <strong>Danger!</strong> Access denied <a href="#" class="alert-link"></a>.
                      </div>
                   </div>
 	          <?php } ?>


 	   <form action="register.php" method="POST"  onsubmit="return validateform()" name="register_form">
           <lable style="color: white;">First name</lable>:<br>
           <input type="text" name="fname" placeholder="firstname" class="form-control" >
           <br>
            <lable style="color: white;">last name</lable>:<br>
           <input type="text" name="lname" placeholder="lastname" class="form-control">
           <br>
            <lable style="color: white;">email</lable>:<br>
           <input type="text" name="email" placeholder="email" class="form-control">
           <br>
             <lable style="color: white;">password</lable>:<br>
           <input type="password" name="password" placeholder="confirm password" class="form-control">
           <br>
            <lable style="color: white;">confirm password</lable>:<br>
           <input type="password" name="confirm" placeholder="confirm password" class="form-control">
           <br>
           <br><br>
           <input type="submit" name="btn_register" value="Register" class="btn btn-success" style="width: 100%">
         <h3 align="center" style="color: white;"><a href="login.php">BACK</a></h3>
 	    </form>	
      
  <div class="col-md-2"></div>
 	</div>
  

 </div>


</body>
</html> 